﻿using DAL.DalModels;
using System;

namespace DAL
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            //DalVirus daf = new DalVirus();
            //daf.naam = "testtest";
            //daf.besmettingsgraad = 0.1m;
            //daf.herkenbaarheidsgraad = 0.1m;
            //daf.sterftegraad = 0.1m;
            //daf.aantalDagenSindsEersteUitbraak = 0;
            //DbVirusContext viruscontext = new DbVirusContext();
            //viruscontext.VirusOpslaanInDatabase(daf);

            //keuze SP beargumenteren in documentatie



        }
    }
}
