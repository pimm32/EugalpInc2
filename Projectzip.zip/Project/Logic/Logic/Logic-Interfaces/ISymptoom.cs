﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logic.Logic_Interfaces
{
    public interface ISymptoom
    {
        public void SymptoomActiveren();
        public void SymptoomDeactiveren();
    }
}
