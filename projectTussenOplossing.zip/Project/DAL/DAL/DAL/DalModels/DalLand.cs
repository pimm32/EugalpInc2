﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DAL.DalModels
{
    public class DalLand
    {
        public string naam { get; set; }
        public int inwonersaantal { get; set; }
        public decimal straatbezetting { get; set; }
        public decimal doktersbezoeken { get; set; }

    }
}
