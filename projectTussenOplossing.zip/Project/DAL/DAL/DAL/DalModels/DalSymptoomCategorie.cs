﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DAL.DalModels
{
    public class DalSymptoomCategorie
    {
        public string naam;
    }
}
