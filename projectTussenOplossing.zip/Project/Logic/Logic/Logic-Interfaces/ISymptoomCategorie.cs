﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logic.Logic_Interfaces
{
    public interface ISymptoomCategorie
    {
        public void SymptoomCategorieVullenMetDataUitDatabase();
    }
}
