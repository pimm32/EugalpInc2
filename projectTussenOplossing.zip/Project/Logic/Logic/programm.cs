﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logic
{
    class programm
    {
        public static void Main()
        {
            
        }
    }
}
